package com.uce.cqrs.dto;

import java.io.Serializable;

public class EmployeeReportDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer salary;
    private String firstName;
    private String lastName;
    private String gender;
    private String deptName;

    public EmployeeReportDTO() {
    }

    // CONSTRUCTOR CON PARÁMETROS
    public EmployeeReportDTO(Integer salary, String firstName, String lastName, String gender, String deptName) {
        this.salary = salary;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.deptName = deptName;
    }

    // Getters y Setters
    public Integer getSalary() { return salary; }
    public void setSalary(Integer salary) { this.salary = salary; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getDeptName() { return deptName; }
    public void setDeptName(String deptName) { this.deptName = deptName; }
}