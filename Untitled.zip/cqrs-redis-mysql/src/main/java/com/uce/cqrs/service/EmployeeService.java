package com.uce.cqrs.service;

import com.uce.cqrs.model.Employee;
import com.uce.cqrs.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.TimeUnit;
import com.uce.cqrs.dto.EmployeeReportDTO;
import java.util.stream.Collectors;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Service
public class EmployeeService {


    @Autowired
    private EmployeeRepository employeeRepository;

    

    // Asegúrate de tener inyectado u obtenido tu ObjectMapper
    private final ObjectMapper objectMapper = new ObjectMapper();

    

  

    public List<EmployeeReportDTO> obtenerReporteGeneral() {
        String redisKey = "reporte:completo";
        
        // Capturamos el tiempo total de inicio del método
        long tiempoInicioMetodo = System.currentTimeMillis();

        try {
            long tiempoInicioRedis = System.currentTimeMillis();
            
            // 1. Intentar recuperar desde Redis como texto plano
            String jsonCachado = redisTemplate.execute(
                (org.springframework.data.redis.connection.RedisConnection connection) -> {
                    byte[] keyBytes = new StringRedisSerializer().serialize(redisKey);
                    byte[] valueBytes = connection.stringCommands().get(keyBytes);
                    return new StringRedisSerializer().deserialize(valueBytes);
                }
            );

            if (jsonCachado != null && !jsonCachado.isEmpty()) {
                List<EmployeeReportDTO> reporteRedis = objectMapper.readValue(
                    jsonCachado, 
                    new TypeReference<List<EmployeeReportDTO>>() {}
                );
                
                long tiempoFinRedis = System.currentTimeMillis();
                System.out.println(">>> [REDIS] ¡Éxito! Reporte masivo (>800) recuperado de la caché.");
                System.out.println(">>> [TIEMPO REDIS] " + (tiempoFinRedis - tiempoInicioRedis) + " ms");
                System.out.println(">>> [TIEMPO TOTAL PETICIÓN] " + (System.currentTimeMillis() - tiempoInicioMetodo) + " ms\n");
                return reporteRedis;
            }
        } catch (Exception e) {
            System.out.println(">>> [REDIS WARNING] Error leyendo caché: " + e.getMessage());
        }

        // 2. Si la caché está vacía, medir el tiempo en MySQL
        long tiempoInicioMysql = System.currentTimeMillis();
        System.out.println(">>> [MYSQL] Ejecutando consulta nativa filtrada y limitada a 1000 en MySQL...");
        
        List<Object[]> filas = employeeRepository.obtenerReporteCompletoNativo();

        List<EmployeeReportDTO> reporteMysql = filas.stream().map(fila -> new EmployeeReportDTO(
                ((Number) fila[0]).intValue(),
                fila[1] != null ? fila[1].toString() : null,
                fila[2] != null ? fila[2].toString() : null,
                fila[3] != null ? fila[3].toString() : null,
                fila[4] != null ? fila[4].toString() : null
        )).collect(Collectors.toList());

        long tiempoFinMysql = System.currentTimeMillis();
        System.out.println(">>> [MYSQL] Consulta completada. Registros procesados: " + reporteMysql.size());
        System.out.println(">>> [TIEMPO MYSQL] " + (tiempoFinMysql - tiempoInicioMysql) + " ms");

        // 3. Guardar el resultado estructurado en Redis como texto plano
        if (!reporteMysql.isEmpty()) {
            try {
                String jsonParaGuardar = objectMapper.writeValueAsString(reporteMysql);
                redisTemplate.execute((org.springframework.data.redis.connection.RedisConnection connection) -> {
                    byte[] keyBytes = new StringRedisSerializer().serialize(redisKey);
                    byte[] valueBytes = new StringRedisSerializer().serialize(jsonParaGuardar);
                    connection.stringCommands().setEx(keyBytes, 300, valueBytes); // 5 minutos
                    return null;
                });
                System.out.println(">>> [REDIS] Reporte masivo guardado en caché correctamente.");
            } catch (Exception e) {
                System.out.println(">>> [REDIS ERROR] No se pudo guardar en caché: " + e.getMessage());
            }
        }

        System.out.println(">>> [TIEMPO TOTAL PETICIÓN] " + (System.currentTimeMillis() - tiempoInicioMetodo) + " ms\n");
        return reporteMysql;
    }

    @Autowired
    private EmployeeRepository mysqlRepository; // Conexión a MySQL (Command DB)

    @Autowired
    private RedisTemplate<String, Object> redisTemplate; // Conexión a Redis (Query DB)

    private static final String CACHE_KEY = "EMP:";
    

    // --- RUTA EXCLUSIVA DE LECTURA (QUERY SERVICE) ---
    public Employee buscarEmpleado(Integer empNo) {
        String claveRedis = CACHE_KEY + empNo;

        // 1. Intentar recuperar el dato desde la Base de Datos de Consulta (Redis en RAM)
        Employee empRedis = (Employee) redisTemplate.opsForValue().get(claveRedis);
        if (empRedis != null) {
            System.out.println(">>> [REDIS] ¡Éxito! Datos recuperados desde la Base de Datos de Lectura (RAM).");
            return empRedis;
        }

        // 2. Cache Miss: Si no está en Redis, baja a la Base de Datos Central (MySQL en Disco)
        System.out.println(">>> [MYSQL] Redis vacío. Extrayendo de MySQL y sincronizando...");
        Employee empMysql = mysqlRepository.findById(empNo)
                .orElseThrow(() -> new RuntimeException("El empleado con ID " + empNo + " no existe."));

        // 3. Sincronización automática: Guardamos una copia en Redis por 5 minutos para próximas consultas
        redisTemplate.opsForValue().set(claveRedis, empMysql, 5, TimeUnit.MINUTES);

        return empMysql;
    }
}