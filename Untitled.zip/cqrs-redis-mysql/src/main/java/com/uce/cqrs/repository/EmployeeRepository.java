package com.uce.cqrs.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.uce.cqrs.model.Employee;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

    @Query(value = "SELECT s.salary, e.first_name, e.last_name, e.gender, d.dept_name " +
                   "FROM employees e " +
                   "JOIN salaries s ON e.emp_no = s.emp_no " +
                   "JOIN dept_emp de ON e.emp_no = de.emp_no " +
                   "JOIN departments d ON de.dept_no = d.dept_no " +
                   "WHERE s.salary > 800 " // <-- Filtro de remuneración
                   ,             // <-- Límite de optimización de memoria
           nativeQuery = true)
    List<Object[]> obtenerReporteCompletoNativo();
}