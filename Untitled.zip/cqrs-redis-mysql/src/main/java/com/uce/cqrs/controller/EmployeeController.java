package com.uce.cqrs.controller;

import com.uce.cqrs.model.Employee;
import com.uce.cqrs.service.EmployeeService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.uce.cqrs.dto.EmployeeReportDTO;

@RestController
@RequestMapping("/ui/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    // Endpoint único para que la UI consulte datos de empleados
    @GetMapping("/view/{id}")
    public ResponseEntity<Employee> viewData(@PathVariable Integer id) {
        return ResponseEntity.ok(employeeService.buscarEmpleado(id));
    }
    
    

    @GetMapping("/reporte")
    public List<EmployeeReportDTO> getReporteGeneral() {
        return employeeService.obtenerReporteGeneral();
    }
    
}